﻿
// LANGSTRINGS

var LANGSTRING_Flash_Warning_Title = 'Aviso!';

var LANGSTRING_Flash_Warning_It_Appears = 'O plugin Flash necessário para visualizar este curso parece não estar instalado.';

var LANGSTRING_Flash_Warning_Click_Here_To_Install = 'Clique aqui para instalar o plugin';

var LANGSTRING_Flash_Warning_Contact_Your_Admin = 'Para obter ajuda sobre como instalar o plugin Flash, entre em contato com o administrador do sistema.';

var LANGSTRING_Flash_Warning_Current_Version = 'Versão atualmente instalada';

var LANGSTRING_Flash_Warning_Required_Version = 'Versão necessária:';

var LANGSTRING_Flash_Warning_If_You_Are_Sure = 'Se a versão atualmente instalada não for detectada corretamente e se você tiver certeza de que a versão necessária ou uma versão posterior está instalada no seu computador, poderá iniciar o curso clicando no link a seguir.';

var LANGSTRING_Flash_Warning_Launch_The_Course = 'Clique aqui para iniciar o curso';

var LANGSTRING_Flash_Object_Desc = 'A principal interface Flash do curso.';

var LANGSTRING_AICC_Check_Before_Unload = 'AVISO: é necessário utilizar um dos botões de saída da lição para receber os créditos.  Tem certeza de que deseja sair?';
